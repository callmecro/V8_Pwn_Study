export class FunctionBuilder {
    constructor() {}
}